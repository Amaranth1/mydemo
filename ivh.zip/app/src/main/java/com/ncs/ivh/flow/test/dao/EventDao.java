package com.ncs.ivh.flow.test.dao;

import com.ncs.ivh.flow.test.model.Event;
import com.ncs.ivh.flow.test.model.Page;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
@Mapper
public interface EventDao {

    public List<Event> findAll();

    public void insert(Event event);

    public List<Event> findPage(Page<Event> page);

    public Integer count(Page<Event> page);
}
