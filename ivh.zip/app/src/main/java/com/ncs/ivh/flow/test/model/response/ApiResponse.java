package com.ncs.ivh.flow.test.model.response;

import com.ncs.ivh.flow.test.model.Page;
import com.ncs.ivh.flow.test.util.JsonMapper;

import java.io.Serializable;
import java.util.List;

public class ApiResponse<T> implements Serializable{
    private int status;

    private String message;

    private T object;

    private List<T> list;

    private Page<T> page;

    public ApiResponse() {
    }

    public ApiResponse<T> withStatus(int status){
        this.status = status;
        return this;
    }

    public ApiResponse<T> withMessage(String message){
        this.message = message;
        return this;
    }

    public ApiResponse<T> withObject(T object){
        this.object = object;
        return this;
    }

    public ApiResponse<T> withList(List<T> list){
        this.list = list;
        return this;
    }

    public ApiResponse<T> withPage(Page<T> page){
        this.page = page;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getObject() {
        return object;
    }

    public void setObject(T object) {
        this.object = object;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public Page<T> getPage() {
        return page;
    }

    public void setPage(Page<T> page) {
        this.page = page;
    }

    @Override
    public String toString() {
        try {
           return JsonMapper.object2Json(this);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
