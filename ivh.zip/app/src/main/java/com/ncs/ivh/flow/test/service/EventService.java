package com.ncs.ivh.flow.test.service;

import com.ncs.ivh.flow.test.dao.EventDao;
import com.ncs.ivh.flow.test.model.Event;
import com.ncs.ivh.flow.test.model.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class EventService implements EventDao{

    @Autowired
    private EventDao eventDao;


    @Override
    public List<Event> findAll() {
        return eventDao.findAll();
    }

    @Override
    public void insert(Event event) {
        eventDao.insert(event);
    }

    @Override
    public List<Event> findPage(Page<Event> page) {
        return eventDao.findPage(page);
    }

    @Override
    public Integer count(Page<Event> page) {
        return eventDao.count(page);
    }
}
