package com.ncs.ivh.flow.test.config;

import com.ncs.ivh.flow.test.model.Event;
import com.ncs.ivh.flow.test.service.EventService;
import com.ncs.ivh.flow.test.util.JsonMapper;
import com.ncs.ivh.flow.test.util.SpringContextHolder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


//as we use the SpringContextHolder that should be loaded by spring earlier
//so use @Lazy to load this component later
@Component
@Lazy
@ServerEndpoint(value="/ws/event/{clientKey}")
public class WebSocketServer {
	private Logger logger = LogManager.getLogger(WebSocketServer.class);
	private Session session;
	private static Map<String, Session> sessionPool = new HashMap<String,Session>();
	private static Map<String, String> sessionIds = new HashMap<String,String>();
	private static final String clientKey = "ivh_workflow_test";
	private EventService eventService = SpringContextHolder.getBean(EventService.class);
	@OnOpen
	public void onOpen(Session session,@PathParam(value="clientKey")String key) {
		logger.info("clientKey:"+key);
		if(clientKey.equals(key)){
            logger.info("sessionId:"+session.getId());
			this.session = session;
			sessionPool.put(key, session);
			sessionIds.put(session.getId(), key);
		}else{
			try {
				session.close(new CloseReason(CloseReason.CloseCodes.CANNOT_ACCEPT,"Illegal client"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	@OnMessage
	public void onMessage(String message) throws Exception{
		logger.info("current sessionId:"+session.getId());
		logger.info("message:"+message);
        String key = sessionIds.get(session.getId());
        Event event = JsonMapper.json2Object(message, Event.class);
        eventService.insert(event);
	}
	
	@OnClose
	public void onClose() {
		logger.info("close session!");
		sessionPool.remove(sessionIds.get(session.getId()));
		sessionIds.remove(session.getId());
	}
	
	@OnError
	public void onError(Session session,Throwable throwable) {
        logger.info("onError!");
		logger.error(throwable.getLocalizedMessage());
	}
	
	
	public static void sendMessgae(String message,String key) {
		Session session = sessionPool.get(key);
		try {
			if(session!=null) {
				session.getBasicRemote().sendText(message);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
}
