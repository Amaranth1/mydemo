package com.ncs.ivh.flow.test.model;

import java.io.Serializable;

public class Event implements Serializable {
    private String id;

    private String sourceId;

    private Integer time;

    private String type;

    private String jsonData;

    private String binaryData;

    private MetaData metaData;

    private Integer timefr;

    private Integer timeto;

    public Event()
    {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getJsonData() {
        return jsonData;
    }

    public void setJsonData(String jsonData) {
        this.jsonData = jsonData;
    }

    public String getBinaryData() {
        return binaryData;
    }

    public void setBinaryData(String binaryData) {
        this.binaryData = binaryData;
    }

    public MetaData getMetaData() {
        return metaData;
    }

    public void setMetaData(MetaData metaData) {
        this.metaData = metaData;
    }

    public Integer getTimefr() {
        return timefr;
    }

    public void setTimefr(Integer timefr) {
        this.timefr = timefr;
    }

    public Integer getTimeto() {
        return timeto;
    }

    public void setTimeto(Integer timeto) {
        this.timeto = timeto;
    }
}
