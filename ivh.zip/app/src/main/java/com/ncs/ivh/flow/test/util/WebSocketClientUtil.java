package com.ncs.ivh.flow.test.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

/**
 * WebSocket client util
 * main task: send message to server and receive a response message
 */
public final class WebSocketClientUtil {

    private static Logger logger = LogManager.getLogger(WebSocketClientUtil.class);

    private static WebSocketClient instance;

    private static volatile String message;

    private WebSocketClientUtil() {
    }

    public static WebSocketClient newInstance(String url) throws Exception{
        if(instance!=null){
            return instance;
        }
        return new WebSocketClient(new URI(url),new Draft_6455()) {
            @Override
            public void onOpen(ServerHandshake serverHandshake) {
                logger.info("onOpen");
            }

            @Override
            public void onMessage(String s) {
                logger.info("onMessage");
                message = s;
            }

            @Override
            public void onClose(int i, String s, boolean b) {
                logger.info("onClose");
            }

            @Override
            public void onError(Exception e) {
                logger.error("onError");
                logger.error(e.getStackTrace());
            }
        };
    }

    public static void connect(){
        instance.connect();
    }

    public static String receiveMessage(){
        return message;
    }

    public static void close(){
        instance.close(200,"client has closed!");
    }

    public static void sendMessage(String msg){
        instance.send(msg);
    }

}
