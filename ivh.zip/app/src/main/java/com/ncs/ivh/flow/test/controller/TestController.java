package com.ncs.ivh.flow.test.controller;

import com.ncs.ivh.flow.test.model.Event;
import com.ncs.ivh.flow.test.model.Page;
import com.ncs.ivh.flow.test.model.response.ApiResponse;
import com.ncs.ivh.flow.test.service.EventService;
import com.ncs.ivh.flow.test.util.JsonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping(value = "/test")
public class TestController {
    @Autowired
    private EventService eventService;

    @RequestMapping(value = "events")
    @ResponseBody
    public String findAllEvents(){
        List<Event> list = eventService.findAll();
        String result = null;
        try {
            result = JsonMapper.object2Json(list);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @RequestMapping(value = "findPage")
    @ResponseBody
    public String findEventPage(@RequestBody Page<Event> page){
        String result = null;
        try {
            List<Event> list = eventService.findPage(page);
            int count = eventService.count(page);
            page.setRows(list);
            page.setTotal(count);
            result = JsonMapper.object2Json(page);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @RequestMapping(value = "insert")
    @ResponseBody
    public String insertEvent(@RequestBody Event event){
        try {
            eventService.insert(event);
            return new ApiResponse().withStatus(200).withMessage("success").toString();
        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse().withStatus(500).withMessage("internal error").toString();
        }

    }
}
