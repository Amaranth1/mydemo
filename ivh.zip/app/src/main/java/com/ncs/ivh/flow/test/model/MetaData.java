package com.ncs.ivh.flow.test.model;

import java.util.Map;

public class MetaData{

    private String id;

    private Map<String,String> description;

    public MetaData() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, String> getDescription() {
        return description;
    }

    public void setDescription(Map<String, String> description) {
        this.description = description;
    }
}
